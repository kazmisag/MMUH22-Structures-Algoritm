
g++ storage.cpp test_storage.cpp -o main -lgtest -lgtest_main -lpthread